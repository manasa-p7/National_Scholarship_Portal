package com.exception;

public class FormValidation extends Exception{

	public FormValidation(String s)
    {
        // Call constructor of parent Exception
        super(s);
    }
}
